import java.util.Scanner;

Student(){
roll = 123456;
name = "Abhishek";

System.out.println(roll+name);

}

public class FirstClass{

public class Student{

int roll;
String name;

public static void main(String[] arg){

Student st = new Student();


}

}













}