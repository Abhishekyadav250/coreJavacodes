import  java.util.*;
import java.util.Scanner;

public class SubString{

    public static void main(String[] ar){

       Scanner sc = new Scanner(System.in);
 
       System.out.print("Enter the  string here   -    ");

       String s1 = sc.nextLine();

System.out.println(s1.substring(0,4));


    }
}