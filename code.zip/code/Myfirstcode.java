package com;

public class Myfirstcode{


public static void main(String arr[]){

System.out.println("Hello World!!!");

}



}