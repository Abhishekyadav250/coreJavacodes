import java.lang.*;
import java.util.*;

public class Basic {
    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
int x = sc.nextInt();
int y =sc.nextInt();
System.out.println(x+"\n"+y);
        
    }
}